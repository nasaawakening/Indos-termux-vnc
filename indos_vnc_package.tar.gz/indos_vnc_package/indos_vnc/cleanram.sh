#!/data/data/com.termux/files/usr/bin/bash
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
echo "RAM cleaned."
