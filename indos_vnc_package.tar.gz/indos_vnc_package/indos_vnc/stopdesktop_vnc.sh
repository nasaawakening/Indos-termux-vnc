#!/data/data/com.termux/files/usr/bin/bash
echo "[INFO] Stopping VNC desktop..."
vncserver -kill :1 2>/dev/null || echo "VNC stopped"
