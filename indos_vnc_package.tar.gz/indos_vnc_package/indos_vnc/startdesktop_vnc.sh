#!/data/data/com.termux/files/usr/bin/bash
echo "[INFO] Starting VNC desktop..."
mkdir -p ~/.vnc
pulseaudio --kill 2>/dev/null
pulseaudio --start 2>/dev/null

# Kill VNC jika masih ada
vncserver -kill :1 2>/dev/null

# Buat password default jika belum ada
if [ ! -f ~/.vnc/passwd ]; then
    echo -e "123456\n123456\nn\n" | vncserver :1 -geometry 1280x720 -depth 24
else
    vncserver :1 -geometry 1280x720 -depth 24
fi

echo "[DONE] VNC desktop started. Connect via :1"
