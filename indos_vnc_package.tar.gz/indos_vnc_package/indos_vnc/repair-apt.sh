#!/data/data/com.termux/files/usr/bin/bash
killall apt apt-get dpkg 2>/dev/null
rm -f /var/lib/dpkg/lock*
dpkg --configure -a
apt -f install -y
apt clean
apt update
echo "Repair complete."
