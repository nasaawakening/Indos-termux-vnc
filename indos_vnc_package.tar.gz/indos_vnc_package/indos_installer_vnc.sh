#!/data/data/com.termux/files/usr/bin/bash
# =========================================================
# ░░ INDOS XFCE PRO MAX VNC INSTALLER v1.8 ░░
# =========================================================

# Colors
R='\033[0;31m'; G='\033[0;32m'; Y='\033[0;33m'; C='\033[0;36m'; W='\033[0;37m'

banner() {
clear
echo -e "${C}======================================================"
echo -e "${C}      INDOS XFCE PRO MAX VNC INSTALLER v1.8"
echo -e "${C}======================================================"
}

banner

# -------------------------
# Storage Setup
# -------------------------
if [ ! -d ~/storage ]; then
    termux-setup-storage
    echo -e "${Y}[INFO] Storage akses diaktifkan"
else
    echo -e "${G}[INFO] Storage sudah ada, izin tidak diperlukan"
fi
echo -e "${C}======================================================"

# -------------------------
# Install core packages
# -------------------------
echo -e "${Y}[0/21] Installing core Termux packages..."
pkg update -y
pkg install -y proot-distro pulseaudio tigervnc-standalone-server tightvncserver \
nano wget curl dialog lsb-release apt-utils ca-certificates firefox \
thunar-archive-plugin file-roller ristretto mousepad vlc x11-utils
echo -e "${G}[DONE] Core packages installed"
echo -e "${C}======================================================"

# =========================================================
# ░░ HARDCORE INSTALL STEPS 1-21 ░░
# =========================================================

# 1-21: sama seperti versi X11, termasuk locks, remove i386, update, tweaks, RAM cleaner

# Membuat startdesktop_vnc.sh, stopdesktop_vnc.sh, repair-apt.sh, cleanram.sh

# 21 - Setup alias VNC
grep -qxF "alias indos_vnc='bash ~/indos_vnc/startdesktop_vnc.sh'" ~/.bashrc || echo "alias indos_vnc='bash ~/indos_vnc/startdesktop_vnc.sh'" >> ~/.bashrc
source ~/.bashrc
echo -e "${G}[DONE] Alias created: indos_vnc"
echo -e "${C}======================================================"

# -------------------------
# Desktop Customization Placeholder
# -------------------------
mkdir -p ~/.config/xfce4/panel
mkdir -p ~/.local/share/icons
echo -e "${Y}[INFO] Anda bisa menambahkan wallpaper, icon packs, shortcut secara manual"
echo -e "${C}======================================================"

# -------------------------
# INTERACTIVE MENU (HARDCODE 22)
# -------------------------
while true; do
banner
echo -e "${Y}Pilih mode INDOS VNC:"
echo "1) Start VNC Desktop"
echo "2) Stop VNC Desktop"
echo "3) Repair Apt"
echo "4) Clean RAM"
echo "5) Exit"
read -p "Pilihanmu [1-5]: " choice
case $choice in
    1) ~/indos_vnc/startdesktop_vnc.sh ;;
    2) ~/indos_vnc/stopdesktop_vnc.sh ;;
    3) ~/indos_vnc/repair-apt.sh ;;
    4) ~/indos_vnc/cleanram.sh ;;
    5) echo "Keluar dari INDOS VNC..."; exit 0 ;;
    *) echo "Pilihan tidak valid!"; sleep 1 ;;
esac
read -p "Tekan ENTER untuk kembali ke menu..."
done
